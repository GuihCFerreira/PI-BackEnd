const server = require('./src/connection/server');

server.initServer();